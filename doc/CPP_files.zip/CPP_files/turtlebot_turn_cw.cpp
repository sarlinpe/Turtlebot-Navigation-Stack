#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <ros/console.h>
#include <iostream>
#include "geometry_msgs/Pose.h"
#include <tf/transform_datatypes.h>
#include <cmath>


class vdpgtController{
    private:
        ros::Subscriber pos_sub;
        ros::Publisher cmd_vel_pub;
        int count;
        double yaw_param , ang_z, ori_z, target_z, init_ang_z,turn_z;
	double PI_0;
	

    public:
        vdpgtController(ros::NodeHandle &nh){
            count = 0;
	    PI_0 =3.1415;
            pos_sub = nh.subscribe("/odom",1,&vdpgtController::callback, this);
            cmd_vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/teleop",1);
        }

        void callback( const nav_msgs::OdometryConstPtr& poseMsg){
        
	geometry_msgs::Twist base_cmd;

	double quatx= poseMsg->pose.pose.orientation.x;
        double quaty= poseMsg->pose.pose.orientation.y;
        double quatz= poseMsg->pose.pose.orientation.z;
        double quatw= poseMsg->pose.pose.orientation.w;
    	tf::Quaternion q(quatx, quaty, quatz, quatw);
	tf::Matrix3x3 m(q);
	double yaw,pitch,roll;
    	m.getRPY(roll, pitch, yaw);

	    target_z =-PI_0/2; // Change orientation angle here		

            ang_z = yaw;
	    
            if(count == 0){
                init_ang_z = yaw;

                count = 1;
            }// count = 0 ends here

	    turn_z = ang_z - init_ang_z;
	    if (turn_z>PI_0){
	    turn_z =turn_z - 2*PI_0;
	    }	
            if(turn_z > target_z){
                yaw_param = -0.1; // Change robot angular velocity
            }else{
                yaw_param = 0;
            }

            base_cmd.angular.z = yaw_param;

            cmd_vel_pub.publish(base_cmd);

    std::cout << "Roll: " << roll << ", Pitch: " << pitch << ", Yaw: " << yaw << std::endl;
            
        }
};

int main(int argc, char** argv){
    ros::init(argc, argv, "curvature_vdpgt");
    ros::NodeHandle nh;
    vdpgtController vc(nh);

    ros::spin();
    return 0;
}
