#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>

#include <iostream>
#include <tf/tfMessage.h>
#include <tf/transform_datatypes.h>
#include <cmath>

class vdpgtController{
    private:
        ros::Subscriber pos_sub;
        ros::Publisher cmd_vel_pub;
        int count;
        double trans_x_param , init_x, init_y, pos_y, pos_x, target_x;
    public:
        vdpgtController(ros::NodeHandle &nh){
            count = 0;
            trans_x_param = 0;
            pos_sub = nh.subscribe("/odom",1,&vdpgtController::callback, this);
            cmd_vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/teleop",1);
        }
        void callback( const nav_msgs::OdometryConstPtr& poseMsg){
            geometry_msgs::Twist base_cmd;
	    target_x =3.5; // Change travel distance here		
            pos_x = poseMsg->pose.pose.position.x;
            pos_y = poseMsg->pose.pose.position.y;
            if(count == 0){
                init_x = poseMsg->pose.pose.position.x;
                init_y = poseMsg->pose.pose.position.y;

                count = 1;
            }// count = 0 ends here

            if(pos_x - init_x <target_x){
                trans_x_param = 0.1; // Change robot velocity
            }else{
                trans_x_param = 0;
            }

            base_cmd.linear.x = trans_x_param;

            cmd_vel_pub.publish(base_cmd);

            std::cout << poseMsg->header.stamp << " " << poseMsg->pose.pose.position.x << " " << poseMsg->pose.pose.position.y << " " <<  trans_x_param  << std::endl;
            
        }
};

int main(int argc, char** argv){
    ros::init(argc, argv, "curvature_vdpgt");
    ros::NodeHandle nh;
    vdpgtController vc(nh);

    ros::spin();
    return 0;
}
